--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.3
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE diary;
--
-- Name: diary; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE diary WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Czech_Czech Republic.1250' LC_CTYPE = 'Czech_Czech Republic.1250';


ALTER DATABASE diary OWNER TO postgres;

\connect diary

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: user_activity_log_changes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.user_activity_log_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
 if OLD.active_session = true then
 delete from user_activity_log where active_session = false and user_id=NEW.user_id;

 end if;
 return new;
end;
$$;


ALTER FUNCTION public.user_activity_log_changes() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: author_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.author_type (
    type_id integer NOT NULL,
    type_descr character varying(150) NOT NULL
);


ALTER TABLE public.author_type OWNER TO postgres;

--
-- Name: author_type_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.author_type_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.author_type_type_id_seq OWNER TO postgres;

--
-- Name: author_type_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.author_type_type_id_seq OWNED BY public.author_type.type_id;


--
-- Name: authors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authors (
    auth_id integer NOT NULL,
    auth_type integer,
    auth_name character varying(150) NOT NULL
);


ALTER TABLE public.authors OWNER TO postgres;

--
-- Name: authors_auth_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.authors_auth_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authors_auth_id_seq OWNER TO postgres;

--
-- Name: authors_auth_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.authors_auth_id_seq OWNED BY public.authors.auth_id;


--
-- Name: books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.books (
    book_id integer NOT NULL,
    book_title character(255) NOT NULL,
    author character(255) NOT NULL,
    book_description text,
    published date
);


ALTER TABLE public.books OWNER TO postgres;

--
-- Name: books_book_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.books_book_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_book_id_seq OWNER TO postgres;

--
-- Name: books_book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.books_book_id_seq OWNED BY public.books.book_id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    comment_id integer NOT NULL,
    comment_datetime timestamp without time zone DEFAULT now() NOT NULL,
    text character(255) NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- Name: comments_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comments_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_comment_id_seq OWNER TO postgres;

--
-- Name: comments_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comments_comment_id_seq OWNED BY public.comments.comment_id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    conversation_id integer NOT NULL,
    user_id1 integer,
    user_id2 integer
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: conversations_conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.conversations_conversation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.conversations_conversation_id_seq OWNER TO postgres;

--
-- Name: conversations_conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.conversations_conversation_id_seq OWNED BY public.conversations.conversation_id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.countries (
    country_code character(4) NOT NULL,
    country_name character(45) DEFAULT NULL::bpchar,
    img_path character(45) DEFAULT NULL::bpchar
);


ALTER TABLE public.countries OWNER TO postgres;

--
-- Name: countries_sights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.countries_sights (
    sight_id integer NOT NULL,
    sight_label character varying(100) NOT NULL,
    country_code character varying(2) NOT NULL,
    img_url character varying(100) DEFAULT NULL::bpchar,
    description character varying(300) DEFAULT NULL::bpchar,
    map_coord_x real,
    map_coord_y real
);


ALTER TABLE public.countries_sights OWNER TO postgres;

--
-- Name: countries_sights_sight_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.countries_sights_sight_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.countries_sights_sight_id_seq OWNER TO postgres;

--
-- Name: countries_sights_sight_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.countries_sights_sight_id_seq OWNED BY public.countries_sights.sight_id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    message_id integer NOT NULL,
    sender_id integer,
    conversation_id integer,
    sent_datetime timestamp without time zone DEFAULT now(),
    text character varying,
    is_read boolean DEFAULT false NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_message_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_message_id_seq OWNER TO postgres;

--
-- Name: messages_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_message_id_seq OWNED BY public.messages.message_id;


--
-- Name: oauth_client_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_client_credentials (
    access_token character varying(800) NOT NULL,
    oauth_client_id character varying(800) NOT NULL,
    oauth_secret character varying(800) NOT NULL,
    refresh_token character varying(800) NOT NULL,
    token_url character varying(800) NOT NULL,
    token_expires bigint NOT NULL,
    credentials_email character varying(300),
    is_refresh_token_valid boolean NOT NULL,
    credentials_id integer NOT NULL
);


ALTER TABLE public.oauth_client_credentials OWNER TO postgres;

--
-- Name: oauth_client_credentials_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_client_credentials_credentials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_client_credentials_credentials_id_seq OWNER TO postgres;

--
-- Name: oauth_client_credentials_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_client_credentials_credentials_id_seq OWNED BY public.oauth_client_credentials.credentials_id;


--
-- Name: password_change_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_change_requests (
    uuid character varying(255) NOT NULL,
    user_id integer NOT NULL,
    created_time timestamp without time zone NOT NULL,
    isuuidused boolean DEFAULT false NOT NULL
);


ALTER TABLE public.password_change_requests OWNER TO postgres;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    post_id integer NOT NULL,
    title character varying(100) NOT NULL,
    text text NOT NULL,
    description text DEFAULT NULL::bpchar NOT NULL,
    sight_id integer NOT NULL,
    user_id integer NOT NULL,
    post_datetime timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: posts_post_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posts_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_post_id_seq OWNER TO postgres;

--
-- Name: posts_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posts_post_id_seq OWNED BY public.posts.post_id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    role_id integer NOT NULL,
    role character varying(45) NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_role_id_seq OWNER TO postgres;

--
-- Name: roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_role_id_seq OWNED BY public.roles.role_id;


--
-- Name: sight_visits_counter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sight_visits_counter (
    visit_id integer NOT NULL,
    sight_id integer NOT NULL,
    user_id integer NOT NULL,
    visit_datetime timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sight_visits_counter OWNER TO postgres;

--
-- Name: sight_visits_counter_visit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sight_visits_counter_visit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sight_visits_counter_visit_id_seq OWNER TO postgres;

--
-- Name: sight_visits_counter_visit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sight_visits_counter_visit_id_seq OWNED BY public.sight_visits_counter.visit_id;


--
-- Name: sight_wishes_counter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sight_wishes_counter (
    wish_id integer NOT NULL,
    sight_id integer NOT NULL,
    user_id integer NOT NULL,
    wish_datetime timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sight_wishes_counter OWNER TO postgres;

--
-- Name: user_activity_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_activity_log (
    user_id integer NOT NULL,
    login_time timestamp without time zone DEFAULT now() NOT NULL,
    login_ip character varying(40),
    user_hostname character varying(100),
    session_id character varying NOT NULL,
    active_session boolean DEFAULT true NOT NULL,
    os character varying,
    browser character varying,
    user_agent character varying
);


ALTER TABLE public.user_activity_log OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(64) NOT NULL,
    email character varying(45) NOT NULL,
    is_enabled boolean,
    information character varying,
    registration_date timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_tokens (
    token_id integer NOT NULL,
    token character varying(10) NOT NULL,
    user_id integer NOT NULL,
    expiration_date bigint NOT NULL,
    is_valid boolean NOT NULL
);


ALTER TABLE public.verification_tokens OWNER TO postgres;

--
-- Name: verification_tokens_token_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.verification_tokens_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.verification_tokens_token_id_seq OWNER TO postgres;

--
-- Name: verification_tokens_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.verification_tokens_token_id_seq OWNED BY public.verification_tokens.token_id;


--
-- Name: wishes_counter_wish_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wishes_counter_wish_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wishes_counter_wish_id_seq OWNER TO postgres;

--
-- Name: wishes_counter_wish_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wishes_counter_wish_id_seq OWNED BY public.sight_wishes_counter.wish_id;


--
-- Name: author_type type_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.author_type ALTER COLUMN type_id SET DEFAULT nextval('public.author_type_type_id_seq'::regclass);


--
-- Name: authors auth_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors ALTER COLUMN auth_id SET DEFAULT nextval('public.authors_auth_id_seq'::regclass);


--
-- Name: books book_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books ALTER COLUMN book_id SET DEFAULT nextval('public.books_book_id_seq'::regclass);


--
-- Name: comments comment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments ALTER COLUMN comment_id SET DEFAULT nextval('public.comments_comment_id_seq'::regclass);


--
-- Name: conversations conversation_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations ALTER COLUMN conversation_id SET DEFAULT nextval('public.conversations_conversation_id_seq'::regclass);


--
-- Name: countries_sights sight_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries_sights ALTER COLUMN sight_id SET DEFAULT nextval('public.countries_sights_sight_id_seq'::regclass);


--
-- Name: messages message_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN message_id SET DEFAULT nextval('public.messages_message_id_seq'::regclass);


--
-- Name: oauth_client_credentials credentials_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_client_credentials ALTER COLUMN credentials_id SET DEFAULT nextval('public.oauth_client_credentials_credentials_id_seq'::regclass);


--
-- Name: posts post_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts ALTER COLUMN post_id SET DEFAULT nextval('public.posts_post_id_seq'::regclass);


--
-- Name: roles role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN role_id SET DEFAULT nextval('public.roles_role_id_seq'::regclass);


--
-- Name: sight_visits_counter visit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sight_visits_counter ALTER COLUMN visit_id SET DEFAULT nextval('public.sight_visits_counter_visit_id_seq'::regclass);


--
-- Name: sight_wishes_counter wish_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sight_wishes_counter ALTER COLUMN wish_id SET DEFAULT nextval('public.wishes_counter_wish_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: verification_tokens token_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_tokens ALTER COLUMN token_id SET DEFAULT nextval('public.verification_tokens_token_id_seq'::regclass);


--
-- Data for Name: author_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.author_type (type_id, type_descr) FROM stdin;
\.
COPY public.author_type (type_id, type_descr) FROM '$$PATH$$/2343.dat';

--
-- Data for Name: authors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authors (auth_id, auth_type, auth_name) FROM stdin;
\.
COPY public.authors (auth_id, auth_type, auth_name) FROM '$$PATH$$/2345.dat';

--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.books (book_id, book_title, author, book_description, published) FROM stdin;
\.
COPY public.books (book_id, book_title, author, book_description, published) FROM '$$PATH$$/2347.dat';

--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments (comment_id, comment_datetime, text, post_id, user_id) FROM stdin;
\.
COPY public.comments (comment_id, comment_datetime, text, post_id, user_id) FROM '$$PATH$$/2349.dat';

--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (conversation_id, user_id1, user_id2) FROM stdin;
\.
COPY public.conversations (conversation_id, user_id1, user_id2) FROM '$$PATH$$/2351.dat';

--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.countries (country_code, country_name, img_path) FROM stdin;
\.
COPY public.countries (country_code, country_name, img_path) FROM '$$PATH$$/2353.dat';

--
-- Data for Name: countries_sights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.countries_sights (sight_id, sight_label, country_code, img_url, description, map_coord_x, map_coord_y) FROM stdin;
\.
COPY public.countries_sights (sight_id, sight_label, country_code, img_url, description, map_coord_x, map_coord_y) FROM '$$PATH$$/2354.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (message_id, sender_id, conversation_id, sent_datetime, text, is_read) FROM stdin;
\.
COPY public.messages (message_id, sender_id, conversation_id, sent_datetime, text, is_read) FROM '$$PATH$$/2356.dat';

--
-- Data for Name: oauth_client_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_client_credentials (access_token, oauth_client_id, oauth_secret, refresh_token, token_url, token_expires, credentials_email, is_refresh_token_valid, credentials_id) FROM stdin;
\.
COPY public.oauth_client_credentials (access_token, oauth_client_id, oauth_secret, refresh_token, token_url, token_expires, credentials_email, is_refresh_token_valid, credentials_id) FROM '$$PATH$$/2371.dat';

--
-- Data for Name: password_change_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_change_requests (uuid, user_id, created_time, isuuidused) FROM stdin;
\.
COPY public.password_change_requests (uuid, user_id, created_time, isuuidused) FROM '$$PATH$$/2358.dat';

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (post_id, title, text, description, sight_id, user_id, post_datetime) FROM stdin;
\.
COPY public.posts (post_id, title, text, description, sight_id, user_id, post_datetime) FROM '$$PATH$$/2359.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (role_id, role) FROM stdin;
\.
COPY public.roles (role_id, role) FROM '$$PATH$$/2361.dat';

--
-- Data for Name: sight_visits_counter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sight_visits_counter (visit_id, sight_id, user_id, visit_datetime) FROM stdin;
\.
COPY public.sight_visits_counter (visit_id, sight_id, user_id, visit_datetime) FROM '$$PATH$$/2363.dat';

--
-- Data for Name: sight_wishes_counter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sight_wishes_counter (wish_id, sight_id, user_id, wish_datetime) FROM stdin;
\.
COPY public.sight_wishes_counter (wish_id, sight_id, user_id, wish_datetime) FROM '$$PATH$$/2365.dat';

--
-- Data for Name: user_activity_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_activity_log (user_id, login_time, login_ip, user_hostname, session_id, active_session, os, browser, user_agent) FROM stdin;
\.
COPY public.user_activity_log (user_id, login_time, login_ip, user_hostname, session_id, active_session, os, browser, user_agent) FROM '$$PATH$$/2366.dat';

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (user_id, role_id) FROM stdin;
\.
COPY public.user_roles (user_id, role_id) FROM '$$PATH$$/2367.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, username, password, email, is_enabled, information, registration_date) FROM stdin;
\.
COPY public.users (user_id, username, password, email, is_enabled, information, registration_date) FROM '$$PATH$$/2368.dat';

--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_tokens (token_id, token, user_id, expiration_date, is_valid) FROM stdin;
\.
COPY public.verification_tokens (token_id, token, user_id, expiration_date, is_valid) FROM '$$PATH$$/2374.dat';

--
-- Name: author_type_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.author_type_type_id_seq', 4, true);


--
-- Name: authors_auth_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.authors_auth_id_seq', 5, true);


--
-- Name: books_book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.books_book_id_seq', 24, true);


--
-- Name: comments_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comments_comment_id_seq', 12, true);


--
-- Name: conversations_conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conversations_conversation_id_seq', 5, true);


--
-- Name: countries_sights_sight_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.countries_sights_sight_id_seq', 33, true);


--
-- Name: messages_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_message_id_seq', 12, true);


--
-- Name: oauth_client_credentials_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_client_credentials_credentials_id_seq', 1, true);


--
-- Name: posts_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posts_post_id_seq', 40, true);


--
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 1, false);


--
-- Name: sight_visits_counter_visit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sight_visits_counter_visit_id_seq', 20, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 41, true);


--
-- Name: verification_tokens_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.verification_tokens_token_id_seq', 1, false);


--
-- Name: wishes_counter_wish_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wishes_counter_wish_id_seq', 7, true);


--
-- Name: author_type author_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.author_type
    ADD CONSTRAINT author_type_pkey PRIMARY KEY (type_id);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (auth_id);


--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (book_id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (comment_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (conversation_id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (country_code);


--
-- Name: countries_sights countries_sights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries_sights
    ADD CONSTRAINT countries_sights_pkey PRIMARY KEY (sight_id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (message_id);


--
-- Name: oauth_client_credentials oauth_client_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_client_credentials
    ADD CONSTRAINT oauth_client_credentials_pkey PRIMARY KEY (credentials_id);


--
-- Name: password_change_requests password_change_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_change_requests
    ADD CONSTRAINT password_change_requests_pkey PRIMARY KEY (uuid);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (post_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: user_activity_log session_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT session_id_pk PRIMARY KEY (session_id);


--
-- Name: user_activity_log session_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT session_id_unique UNIQUE (session_id);


--
-- Name: sight_visits_counter sight_visits_counter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sight_visits_counter
    ADD CONSTRAINT sight_visits_counter_pkey PRIMARY KEY (visit_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: verification_tokens verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_pkey PRIMARY KEY (token_id);


--
-- Name: sight_wishes_counter wishes_counter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sight_wishes_counter
    ADD CONSTRAINT wishes_counter_pkey PRIMARY KEY (wish_id);


--
-- Name: user_activity_log user_activity_changes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER user_activity_changes BEFORE UPDATE ON public.user_activity_log FOR EACH ROW EXECUTE PROCEDURE public.user_activity_log_changes();


--
-- Name: authors authors_auth_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_auth_type_fkey FOREIGN KEY (auth_type) REFERENCES public.author_type(type_id);


--
-- Name: comments comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(post_id);


--
-- Name: comments comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: conversations conversations_user_id1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_user_id1_fkey FOREIGN KEY (user_id1) REFERENCES public.users(user_id);


--
-- Name: conversations conversations_user_id2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_user_id2_fkey FOREIGN KEY (user_id2) REFERENCES public.users(user_id);


--
-- Name: countries_sights countries_sights_country_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries_sights
    ADD CONSTRAINT countries_sights_country_code_fkey FOREIGN KEY (country_code) REFERENCES public.countries(country_code);


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(conversation_id);


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(user_id);


--
-- Name: password_change_requests password_change_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_change_requests
    ADD CONSTRAINT password_change_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: sight_visits_counter sight_visits_counter_sight_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sight_visits_counter
    ADD CONSTRAINT sight_visits_counter_sight_id_fkey FOREIGN KEY (sight_id) REFERENCES public.countries_sights(sight_id);


--
-- Name: sight_visits_counter sight_visits_counter_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sight_visits_counter
    ADD CONSTRAINT sight_visits_counter_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: user_activity_log user_activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(role_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: verification_tokens verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sight_wishes_counter wishes_counter_sight_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sight_wishes_counter
    ADD CONSTRAINT wishes_counter_sight_id_fkey FOREIGN KEY (sight_id) REFERENCES public.countries_sights(sight_id);


--
-- Name: sight_wishes_counter wishes_counter_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sight_wishes_counter
    ADD CONSTRAINT wishes_counter_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

